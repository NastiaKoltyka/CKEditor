import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-buttons',
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.css']
})
export class ButtonsComponent implements OnInit {
visible:boolean
  constructor() { 
    this.visible=false
  }

  ngOnInit(): void {
  }
  ItVisible(){
    if(!this.visible){
      this.visible=true
    }
    else{
      this.visible=false
    }
  }
}
