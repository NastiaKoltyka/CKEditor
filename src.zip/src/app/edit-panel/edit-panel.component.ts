import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import{FormsModule} from '@angular/forms'

@Component({
  selector: 'app-edit-panel',
  templateUrl: './edit-panel.component.html',
  styleUrls: ['./edit-panel.component.css']
})
export class EditPanelComponent implements OnInit {
  @Input() visible:boolean
  @Output() innerHTML = new EventEmitter();
  constructor() { 
    this.visible=false
    this.innerHTML.emit(this.innerHTML);

  }

  ngOnInit(): void {
    console.log(this.innerHTML)
  }

}
