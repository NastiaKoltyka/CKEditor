import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { FinalTextComponent } from './final-text/final-text.component';
import { ButtonsComponent } from './buttons/buttons.component';
import { EditPanelComponent } from './edit-panel/edit-panel.component';
import { StylePanelComponent } from './style-panel/style-panel.component';

@NgModule({
  declarations: [
    AppComponent,
    FinalTextComponent,
    ButtonsComponent,
    EditPanelComponent,
    StylePanelComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
