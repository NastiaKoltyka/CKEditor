import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-final-text',
  templateUrl: './final-text.component.html',
  styleUrls: ['./final-text.component.css']
})
export class FinalTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
